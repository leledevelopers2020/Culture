package com.example.myculture;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class Allinone extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_allinone);
        TextView  txt=(TextView)findViewById(R.id.text);
        txt.setText("hello");
        Integer no=getIntent().getExtras().getInt("c");
        String name=getIntent().getExtras().getString("name");
        switch (name)
        {
            case "vrath":
                {
                    switch (no)
                    {
                        case 0:

                            txt.setText("Pradosh");
                            break;
                        case 1:
                            txt.setText("Ekadashi");
                            break;
                        case 2:
                            txt.setText("Poonam");
                            break;
                        case 3:
                            txt.setText("Amavasya");
                            break;
                    }
                 }
                break;
            case "aarthi": {
                switch (no) {
                    case 0:
                        txt.setText("Ganesh");
                        break;
                    case 1:
                        txt.setText("Durga");
                        break;
                    case 2:
                        txt.setText("Shankar");
                        break;
                    case 3:
                        txt.setText("Hanuman");
                        break;
                }
            }
                break;
            case "chalisa": {
                switch (no) {
                    case 0:
                        txt.setText("Ganesh Ji");
                        break;
                    case 1:
                        txt.setText("Durga Ji");
                        break;
                    case 2:
                        txt.setText("Shankar Ji");
                        break;
                    case 3:
                        txt.setText("Hanuman Ji");
                        break;
                }
            }
                break;
        }

    }
}
